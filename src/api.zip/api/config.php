<?php
function cargarEnv(string $path): void {
    if (!file_exists($path)) return;
    $lineas = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lineas as $linea) {
        if (str_starts_with(trim($linea), '#')) continue;
        [$clave, $valor] = explode('=', $linea, 2);
        $_ENV[trim($clave)] = trim($valor);
    }
}

cargarEnv(__DIR__ . '/../../.env');

define('DB_HOST',    'sql201.infinityfree.com');
define('DB_USER',    'if0_41659065');
define('DB_PASS',    'P3PP3R5123');
define('DB_NAME',    'if0_41659065_sistema_auth');
define('JWT_SECRET', 'una_clave_secreta_segura');